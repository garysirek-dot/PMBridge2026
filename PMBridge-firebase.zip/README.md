# PMBridge

Project-management web app for campus trailer/building deployments: campuses → projects → phases and tasks, Action Register, My Stuff board, Status, Calendar + Gantt, Tools (Notepad, Punchlists, Estimator, Templates).

Single-page app: everything is in `public/index.html`. No build step.

## How data is stored
- **Shared (Firestore):** `projects/{campusId}` (one doc per campus, plus `projects/__program` for the Program page and General Tasks) and `estimator/prices` (price list, labor %, custom lines, line order, estimate templates).
- **Per browser (localStorage):** an offline copy of the data plus view settings (filters, board layout, Gantt zoom, collapsed cards).
- Users sign in with Google (Firebase Authentication) before the shared data loads.

## Deploy (Firebase Hosting)
```bash
npm install -g firebase-tools
firebase login
firebase deploy --only hosting,firestore:rules
```
Site: https://missioncritical-rda-dev-001.web.app

One-time setup in the Firebase console:
1. Authentication → Sign-in method → enable **Google**.
2. Authentication → Settings → Authorized domains → add any other web address the app is served from.
3. Firestore Database → create (Native mode) if it doesn't exist yet.
4. Edit `firestore.rules` to restrict access to the company email domain, then deploy.

Optional: `firebase init hosting:github` adds a GitHub Action that deploys on every push to `main`.

## Releasing a change
1. Edit `public/index.html`.
2. Bump `APP_VERSION` in index.html and `VERSION` in `public/sw.js` (e.g. `pmbridge-v151`) so installed copies pick up the update.
3. Commit, push, deploy.

## Moving data in
In the old copy: ⋯ menu → **Back up my data (download)**. In the new site, signed in: ⋯ → **Restore from a backup file**. Restore replaces everything and uploads it to Firestore.
