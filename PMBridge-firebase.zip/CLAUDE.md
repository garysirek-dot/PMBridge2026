# PMBridge — context for Claude

Read this before changing anything. It replaces the original chat history (the app was built over ~150 versions in a personal Claude account).

## What it is
PMBridge is a single-file web app (`public/index.html`, ~620 KB of HTML/CSS/JS, no framework, no build step) for managing campus deployments (trailers and buildings). Owner: Gary Sirek. Dark UI: black page, charcoal rounded cards, each campus has a color.

Tabs: **Campuses** (home; campus tiles → campus page with project cards, phases, tasks, Action Register, notes, punchlists, Contact/site info, documents), **My Stuff** (board: General Tasks card + campus cards grouped Project → Phase → items, three draggable columns), **Status** (Update/Blocker table), **Calendar** (Gantt + Critical Path cards + month calendar showing only each project's Contracts date and full Installation span), **Tools** (Notepad, Punchlists, Estimator with Trailer/Building tabs, price list and estimate templates, Templates for phases/tasks with T-minus Friday dates). The Program page opens only from the PMBridge logo.

## Data
- `state.projects` = array of campus objects (`cleanProject` normalizes them). Special ids: `__program` (Program page; its register card holds General Tasks), `__reg` register card.
- Shared storage: Firestore via the Firebase module in `<head>`. It exposes `window.claude.use("db")` returning `{collection(name).onSnapshot, doc(path).set/delete}` — the sync layer (`writeNow` → `syncAll`/`queueSync`/`flushSync`, `connectStore`, `watchPrices`/`pushPrices`) was written against that shape and should not need changes.
- Docs: `projects/{campusId}` (whole campus + `order`), `estimator/prices` `{items, labor, custom, order, tpls}`. Last write wins per campus document.
- localStorage keys start with `pmbridge-` (`pmbridge-v1` = offline copy of projects). View preferences stay local on purpose.

## Conventions when editing
- Patch `public/index.html` in place with exact-string replacements; never rewrite the whole file.
- Every release: bump `APP_VERSION` (e.g. `"151 (Dec 1)"`) and `VERSION` in `public/sw.js` (`pmbridge-v151`).
- After editing, syntax-check the main script (extract the `<script>` blocks and run `node --check`) and click through the changed screen in a browser.
- Don't put code after a `//` comment on the same line (it has broken builds before); use `/* */` for inline comments.
- Keep the look consistent: compact rounded-rectangle buttons, uppercase letter-spaced headings, campus color accents, one-line rows where possible.

## Owner preferences learned so far
- Wants changes delivered quickly, tested, and summarized briefly.
- Likes compact, symmetrical layouts; no word-wrapping in list rows; past-due dates as solid red pills.
- Phase dates land on Fridays (T-minus from install: Pre-install = Friday before install, Procurement 28 days before that, Contracts 7 days before that, Planning 56 days before install).
